var box;



function setup() {
  createCanvas(400,400);
  box = createSprite(200, 200, 20,20);
  box.shapeColor = "white";
}

function draw() 
{
  background("gray");
  if(keyDown("d")){
    box.position.x += 1;
  }
  if(keyDown("a")){
    box.position.x -= 1;
  }

  if(keyDown("w")){
    box.position.y -= 1;
  }
  if(keyDown("s")){
    box.position.y += 1;
  }
  drawSprites();
}
